#!/bin/sh

# generate oem specific prompt
if grep -q branding: /oem/*/*/meta/package.yaml 2>/dev/null; then
  NAME="$(grep -oPz 'branding:\n.*name:(.*)' /oem/*/*/meta/package.yaml|tail -1|cut -d: -f2 | tr -d ' ' )"
  export debian_chroot="$NAME"
fi


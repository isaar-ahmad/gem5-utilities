# expand PATH
PATH=$PATH:/apps/bin
